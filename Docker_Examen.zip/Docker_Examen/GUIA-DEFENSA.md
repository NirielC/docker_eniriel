# Guía para la defensa: Tema 10, Retos de programación

Respuestas cortas a lo que te pueden preguntar. Abre el archivo que se menciona mientras lo explicas.

---

## Parte 1: React

**¿De qué trata la app?**
Se llama **Retoma** (reto + retomar). Muestra **bloques** de preguntas de programación (Fundamentos,
React, Docker, Chatbots y NLP, APIs en C# y Kotlin). Cada bloque tiene de 5 a 6 preguntas que se
responden una por una. Al responder bien se suman puntos y el avance se guarda en localStorage.

**¿Cómo está organizada la app?**
`App.jsx` es el componente padre: guarda el estado importante (progreso, historial, nombre del jugador,
vista actual, bloque abierto y filtro) y se lo pasa a los hijos por **props**. Los hijos avisan al padre
mediante funciones que reciben como props (`onAbrir`, `onValidar`, `onUsarPista`...).
Esto se llama **elevar el estado** (lifting state up).

Árbol principal: `App` → `Sidebar`, `Encabezado`, `Estadisticas`, `FiltroCategorias`, `ListaBloques` →
`TarjetaBloque`. Al abrir un bloque: `DetalleBloque` → `Pregunta` → `OpcionesRespuesta` / `EditorCodigo` /
`ResultadoValidacion`. A la derecha siempre está `PanelJugador`.

**¿Qué hooks usaste?**
- `useState`: para valores que cambian y redibujan la pantalla (ej. `vista`, `filtro`, la pregunta actual del bloque, la opción seleccionada, el código escrito).
- `useEffect`: dentro de `useLocalStorage`, para guardar en localStorage cada vez que cambia el valor.
- **Hook personalizado** `useLocalStorage` (`src/hooks/useLocalStorage.js`): funciona como `useState`, pero
  lee el valor inicial de localStorage y lo guarda cuando cambia. Usa `JSON.stringify` para guardar y `JSON.parse` para leer.

**¿Dónde se guardan los datos?**
En **localStorage**, con tres claves: `retoma-progreso`, `retoma-historial` y `retoma-jugador`.
El progreso guarda, por cada pregunta, si está completada, sus puntos, los intentos y si usó la pista.
Por eso al recargar la página no se pierde nada. Las preguntas están en `src/data/retos.js`.

**¿Qué eventos de React hay?**
`onClick` (tarjetas, botones, opciones, pasos), `onChange` (input y editor), `onSubmit` (formulario de respuesta),
`onKeyDown` (Tab inserta espacios y Ctrl+Enter valida en el editor).

**¿Cómo muestras la lista de bloques?**
Con `bloques.map(...)`, devolviendo un `<TarjetaBloque key={bloque.id} />` por cada bloque.
La `key` sirve para que React identifique cada elemento y actualice solo lo que cambió.

**¿Por qué `<Pregunta key={pregunta.id} />` y `<DetalleBloque key={bloqueActivo.id} />`?**
Al cambiar la `key`, React desmonta el componente y crea uno nuevo, así se **limpia su estado**
(la respuesta escrita, la opción seleccionada y el resultado) al pasar a otra pregunta u otro bloque.

**¿Cómo cambias de pantalla sin React Router?**
Con **renderizado condicional** en `App.jsx`: si hay un bloque abierto se muestra `DetalleBloque`, si
`vista === 'progreso'` se muestra `VistaProgreso` y si no, la lista. Se usa el operador ternario `? :` y `&&`.
Dentro de `DetalleBloque` pasa lo mismo: muestra la `Pregunta` actual o el resumen del bloque.

**¿Cómo se calculan los puntos, el porcentaje y el nivel?**
Son **datos derivados**: no se guardan en el estado, se calculan en cada render a partir de `progreso`
(con `filter` y `reduce`). La función `resumenDe(bloque)` calcula cuántas preguntas del bloque están
resueltas y sus puntos. Porcentaje = preguntas resueltas / total × 100. Nivel = puntos / 50 + 1.

**¿Cómo funcionan los puntos?**
Depende del tipo de pregunta (`PUNTOS_POR_TIPO`): verdadero/falso 5, opción múltiple 10,
respuesta corta 10 y código 15. Si usas la pista pierdes la mitad. Solo se suman la **primera vez**
que respondes bien la pregunta (función `validar` en `App.jsx`).

---

## Parte 2: Validación de criterios (`src/utils/validar.js`)

Hay 4 tipos de pregunta y cada una trae sus **criterios predefinidos** en `retos.js`:

| Tipo | Criterio | Cómo se valida |
| --- | --- | --- |
| `vf` | `respuesta` (true/false) | Se convierte en opción múltiple con "Verdadero" y "Falso" |
| `opcion` | `correcta` (índice) | Se compara el índice seleccionado con el correcto |
| `respuesta` | `respuestasValidas` | Se **normaliza** el texto (minúsculas, sin espacios extra ni comillas) y se compara con la lista |
| `codigo` | `pruebas`, `requiere`, `prohibe` | Se ejecuta el código y se revisa cada caso de prueba |

**¿Cómo ejecutas el código que escribe el usuario?**
Con `new Function(...)`, que convierte el texto en una función real de JavaScript. Luego se llama a esa
función con la entrada de cada prueba y se compara el resultado con el esperado usando `JSON.stringify`
(así también se pueden comparar arreglos). Todo va dentro de `try/catch` para mostrar los errores sin romper la app.
Las preguntas de C#, Kotlin y Docker no ejecutan código (el navegador solo ejecuta JavaScript): son de
opción múltiple, verdadero/falso o "¿qué imprime este código?".

**¿Cómo sabes si usó `for` o `map`?**
Primero se quitan los comentarios del código y luego se busca la palabra con una expresión regular (`RegExp`).

**¿Cómo agrego una pregunta o un bloque nuevo?**
Agrego un objeto al arreglo `BLOQUES_BASE` en `src/data/retos.js` (o una pregunta dentro de un bloque) con
su tipo y sus criterios. Al final del archivo, un `map` le pone a cada pregunta su `id` y sus puntos.
No hay que tocar ningún componente: la app la muestra y la valida automáticamente.

---

## Parte 3: CSS y diseño

- Paleta de colores guardada como **variables CSS** en `:root` (`--rojo`, `--azul`, `--mantequilla`, `--rosa`).
- Fuentes: **Montserrat** para los textos e **Instrument Serif** en lugar de Adogare (Adogare no es gratuita).
  Se instalaron con npm (`@fontsource`) para que funcionen **sin internet** dentro del contenedor.
- Layout con **CSS Grid** (sidebar | contenido | panel) y **Flexbox** dentro de los componentes.
- **Media queries**: en pantallas pequeñas el panel baja y la barra lateral se vuelve barra inferior.
- Íconos: SVG propios estilo sticker (cada figura se dibuja dos veces: blanca gruesa detrás y oscura encima).
- Animaciones con `@keyframes` (sello al resolver, sacudida en respuesta incorrecta).

---

## Parte 4: Docker

**¿Qué es Docker?** Una plataforma para empaquetar una app con todas sus dependencias en un
**contenedor** que funciona igual en cualquier máquina.

**Imagen vs. contenedor:** la **imagen** es la plantilla (se crea con el Dockerfile); el **contenedor**
es la imagen ejecutándose.

**Docker vs. máquina virtual:** la VM carga un sistema operativo completo; el contenedor comparte el
kernel del sistema anfitrión, por eso es más ligero y arranca en segundos.

### Dockerfile, línea por línea

| Línea | Qué hace |
| --- | --- |
| `FROM node:24-alpine` | Imagen base: Node.js 24 sobre Alpine Linux (ligera) |
| `WORKDIR /app` | Carpeta de trabajo dentro del contenedor |
| `COPY package*.json ./` | Copia primero solo package.json, así Docker **reutiliza la caché** de `npm install` si no cambian las dependencias |
| `RUN npm install` | Instala las dependencias durante la construcción |
| `COPY . .` | Copia el resto del proyecto |
| `RUN npm run build` | Compila el proyecto; si hay un error, la imagen no se crea |
| `EXPOSE 5173` | Documenta el puerto que usa la app (no lo abre por sí solo) |
| `CMD [...]` | Comando al iniciar el contenedor: `npm run dev -- --host 0.0.0.0 --port 5173` |

**¿Por qué `--host 0.0.0.0`?** Porque Vite por defecto solo escucha en `localhost` *dentro* del
contenedor; con `0.0.0.0` acepta conexiones desde fuera (desde tu navegador).

**¿Para qué sirve `.dockerignore`?** Para que Docker **no copie** archivos innecesarios a la imagen,
sobre todo `node_modules` (se instalan dentro del contenedor).

### compose.yaml, línea por línea

| Línea | Qué hace |
| --- | --- |
| `services:` | Lista de servicios (contenedores) |
| `app:` | Nombre del servicio |
| `build: context: .` / `dockerfile: Dockerfile` | Construye la imagen con el Dockerfile de esta carpeta |
| `image: usuario/retos-app:v1.0` | Nombre y **versión (tag)** de la imagen; así ya queda lista para subir a Docker Hub |
| `container_name: retos-app` | Nombre del contenedor |
| `ports: "5173:5173"` | Puerto de tu PC : puerto del contenedor |
| `volumes: .:/app` | Sincroniza los archivos del proyecto con el contenedor (los cambios se ven al instante) |
| `volumes: /app/node_modules` | Conserva los node_modules instalados dentro del contenedor |
| `restart: unless-stopped` | Reinicia el contenedor si se detiene inesperadamente |

**¿Por qué Compose y no solo `docker build` + `docker run`?** Porque en un solo archivo YAML queda toda
la configuración (puertos, volúmenes, nombre, versión) y se levanta con un solo comando. Compose sigue
usando el Dockerfile para construir la imagen.

**En `vite.config.js` puse `usePolling: true`**: en Windows los cambios de archivos que pasan por el
volumen no siempre se detectan; con polling Vite revisa los archivos periódicamente.

### Comandos

| Objetivo | Comando |
| --- | --- |
| Construir e iniciar | `docker compose up --build` |
| En segundo plano | `docker compose up -d --build` |
| Ver contenedores | `docker compose ps` |
| Ver registros | `docker compose logs -f` |
| Detener y eliminar | `docker compose down` |
| Ver imágenes | `docker images` |
| Iniciar sesión | `docker login` |
| Subir a Docker Hub | `docker push usuario/retos-app:v1.0` |
| Descargar | `docker pull usuario/retos-app:v1.0` |
| Entrar al contenedor | `docker compose exec app sh` |

**¿Qué es Docker Hub?** Un repositorio en la nube para imágenes de Docker, como GitHub pero para imágenes.
`push` sube la imagen y `pull` la descarga. El **tag** (`v1.0`) identifica la versión.

### Problemas comunes

- *"port is already allocated"*: el puerto 5173 está ocupado. Hay que cerrar el `npm run dev` local o cambiar a `"5174:5173"`.
- *"Cannot connect to the Docker daemon"*: Docker Desktop no está abierto.
- *"denied: requested access"* al hacer push: no hiciste `docker login` o el usuario del tag no es el tuyo.
